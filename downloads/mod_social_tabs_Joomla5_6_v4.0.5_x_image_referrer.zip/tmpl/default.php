<?php

defined('_JEXEC') or die;

use Joomla\CMS\Uri\Uri;

/** @var array $viewModel */
if (empty($viewModel['networks'])) {
    return;
}

$root = Uri::root(true) . '/media/mod_social_tabs/images/';
$esc = static fn(string $value): string => htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
$start = max(0, min((int) $viewModel['start'], count($viewModel['networks']) - 1));
$isOpen = $viewModel['method'] === 'static' || !empty($viewModel['loadOpen']);
$side = str_contains((string) $viewModel['location'], 'right') ? 'right' : 'left';
$vertical = str_starts_with((string) $viewModel['location'], 'bottom') ? 'bottom' : (str_starts_with((string) $viewModel['location'], 'middle') ? 'middle' : 'top');
$style = '--socialtabs-width:' . (int) $viewModel['width'] . 'px;--socialtabs-height:' . (int) $viewModel['height'] . 'px;--socialtabs-offset:' . (int) $viewModel['offset'] . 'px;';
?>
<div
    id="<?= $esc($viewModel['id']) ?>"
    class="socialtabs-social-tabs <?= $isOpen ? 'is-open ' : '' ?><?= $esc($viewModel['moduleClass']) ?>"
    style="<?= $esc($style) ?>"
    data-socialtabs-social-tabs
    data-method="<?= $esc($viewModel['method']) ?>"
    data-position="<?= $esc($viewModel['position']) ?>"
    data-location="<?= $esc($viewModel['location']) ?>"
    data-side="<?= $side ?>"
    data-vertical="<?= $vertical ?>"
    data-offset="<?= (int) $viewModel['offset'] ?>"
    data-width="<?= (int) $viewModel['width'] ?>"
    data-height="<?= (int) $viewModel['height'] ?>"
    data-start="<?= $start ?>"
    data-load-open="<?= $viewModel['loadOpen'] ? '1' : '0' ?>"
    data-auto-close="<?= $viewModel['autoClose'] ? '1' : '0' ?>"
>
    <div class="socialtabs-social-tabs__tabs" role="tablist" aria-label="Social networks">
        <?php foreach ($viewModel['networks'] as $index => $network) : $active = $index === $start; ?>
            <button
                type="button"
                class="socialtabs-social-tabs__tab socialtabs-tab-<?= $esc($network['key']) ?><?= $active ? ' is-active' : '' ?>"
                role="tab"
                aria-selected="<?= $active ? 'true' : 'false' ?>"
                data-tab-index="<?= (int) $index ?>"
                title="<?= $esc($network['label']) ?>"
            >
                <img src="<?= $esc($root . $network['icon']) ?>" alt="<?= $esc($network['label']) ?>">
            </button>
        <?php endforeach; ?>
    </div>

    <div class="socialtabs-social-tabs__shell">
        <?php foreach ($viewModel['networks'] as $index => $network) : $active = $index === $start; ?>
            <section class="socialtabs-social-tabs__panel socialtabs-panel-<?= $esc($network['key']) ?>" role="tabpanel" data-panel-index="<?= (int) $index ?>"<?= $active ? '' : ' hidden' ?>>
                <header class="socialtabs-social-tabs__header">
                    <div class="socialtabs-social-tabs__title">
                        <img src="<?= $esc($root . $network['icon']) ?>" alt="">
                        <span><?= $esc($network['title']) ?></span>
                    </div>
                    <?php if ($network['profileUrl'] !== '') : ?>
                        <a class="socialtabs-social-tabs__open" href="<?= $esc($network['profileUrl']) ?>" target="_blank" rel="noopener noreferrer"><?= $esc($network['button']) ?></a>
                    <?php endif; ?>
                </header>

                <div class="socialtabs-social-tabs__content">
                    <?php if ($network['error'] !== '') : ?>
                        <div class="socialtabs-social-tabs__error"><?= $esc($network['error']) ?></div>
                    <?php elseif (empty($network['items'])) : ?>
                        <div class="socialtabs-social-tabs__empty">Нет публикаций для отображения.</div>
                    <?php else : ?>
                        <div class="socialtabs-social-tabs__stream">
                            <?php foreach ($network['items'] as $item) : ?>
                                <article class="socialtabs-social-tabs__post">
                                    <?php if ($item['url'] !== '') : ?><a href="<?= $esc($item['url']) ?>" target="_blank" rel="noopener noreferrer" class="socialtabs-social-tabs__post-link"><?php endif; ?>
                                    <?php if ($item['image'] !== '') : ?>
                                        <img class="socialtabs-social-tabs__post-image"<?= $network['key'] === 'x' ? ' referrerpolicy="no-referrer"' : '' ?> src="<?= $esc($item['image']) ?>" loading="lazy" decoding="async" alt="">
                                    <?php endif; ?>
                                    <div class="socialtabs-social-tabs__post-copy">
                                        <?php if ($item['title'] !== '') : ?><strong class="socialtabs-social-tabs__post-title"><?= $esc($item['title']) ?></strong><?php endif; ?>
                                        <?php if ($item['text'] !== '') : ?><div class="socialtabs-social-tabs__post-text"><?= nl2br($esc($item['text'])) ?></div><?php endif; ?>
                                    </div>
                                    <?php if ($item['url'] !== '') : ?></a><?php endif; ?>

                                    <footer class="socialtabs-social-tabs__post-footer">
                                        <?php if ($item['date'] !== '') : ?><time><?= $esc($item['date']) ?></time><?php endif; ?>
                                        <span class="socialtabs-social-tabs__profiles">
                                            <?php foreach ($viewModel['profileLinks'] as $profile) : ?>
                                                <a href="<?= $esc($profile['url']) ?>" target="_blank" rel="noopener noreferrer" title="<?= $esc($profile['label']) ?>">
                                                    <img src="<?= $esc($root . $profile['icon']) ?>" alt="<?= $esc($profile['label']) ?>">
                                                </a>
                                            <?php endforeach; ?>
                                        </span>
                                    </footer>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        <?php endforeach; ?>

        <div class="socialtabs-social-tabs__controls" aria-label="Social feed controls">
            <button type="button" data-action="pause" title="Пауза">Ⅱ</button>
            <button type="button" data-action="up" title="Вверх">↑</button>
            <button type="button" data-action="down" title="Вниз">↓</button>
            <button type="button" data-action="close" title="Закрыть">×</button>
        </div>
    </div>
</div>
