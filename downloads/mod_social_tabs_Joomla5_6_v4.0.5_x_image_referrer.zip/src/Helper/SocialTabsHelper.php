<?php

namespace SocialTabs\Module\SocialTabs\Site\Helper;

defined('_JEXEC') or die;

use Joomla\Registry\Registry;
use SocialTabs\Module\SocialTabs\Site\Service\FeedService;

final class SocialTabsHelper
{
    public const SUPPORTED = ['x', 'facebook', 'instagram', 'youtube', 'rss'];

    public static function buildViewModel(Registry $params, int $moduleId): array
    {
        $all = self::toArray($params->get('show_list_icon'));
        $prefetch = FeedService::prefetch($params, $moduleId);
        $networks = [];

        foreach (self::SUPPORTED as $key) {
            if (!isset($all[$key])) {
                continue;
            }

            $cfg = self::toArray($all[$key]);
            $network = self::buildNetwork($key, $cfg, $prefetch[$key] ?? null);
            if ($network !== null) {
                $networks[] = $network;
            }
        }

        // Preserve the order saved by the custom field instead of SUPPORTED order.
        $ordered = [];
        foreach (array_keys($all) as $savedKey) {
            foreach ($networks as $network) {
                if ($network['key'] === $savedKey) {
                    $ordered[] = $network;
                    break;
                }
            }
        }
        if ($ordered) {
            $networks = $ordered;
        }

        $profileLinks = [];
        foreach ($networks as $network) {
            if ($network['profileUrl'] !== '') {
                $profileLinks[] = [
                    'key' => $network['key'],
                    'label' => $network['label'],
                    'url' => $network['profileUrl'],
                    'icon' => $network['icon'],
                ];
            }
        }

        return [
            'id' => 'socialtabs-social-tabs-' . $moduleId,
            'moduleId' => $moduleId,
            'networks' => $networks,
            'profileLinks' => $profileLinks,
            'method' => $params->get('mod_method', 'slide') === 'static' ? 'static' : 'slide',
            'position' => $params->get('mod_position', 'fixed') === 'absolute' ? 'absolute' : 'fixed',
            'location' => self::safeLocation((string) $params->get('mod_location', 'top-left')),
            'offset' => max(0, (int) $params->get('mod_offset', 20)),
            'width' => max(260, min(900, (int) $params->get('mod_width', 500))),
            'height' => max(260, min(1200, (int) $params->get('mod_height', 700))),
            'loadOpen' => (bool) $params->get('mod_loadOpen', 1),
            'autoClose' => (bool) $params->get('mod_autoClose', 1),
            'start' => self::startIndex($networks, (string) $params->get('mod_tabFirstIndex', 'facebook')),
            'moduleClass' => trim((string) $params->get('moduleclass_sfx', '')),
        ];
    }

    private static function buildNetwork(string $key, array $cfg, mixed $feed): ?array
    {
        return match ($key) {
            'x' => self::networkX($cfg, $feed),
            'facebook' => self::networkFacebook($cfg, $feed),
            'instagram' => self::networkInstagram($cfg, $feed),
            'youtube' => self::networkYoutube($cfg, $feed),
            'rss' => self::networkRss($cfg, $feed),
            default => null,
        };
    }

    private static function networkX(array $cfg, mixed $feed): array
    {
        $source = trim((string) ($cfg['mod_XProfile'] ?? ''));
        $handle = preg_replace('~^https?://(?:www\.)?x\.com/~i', '', $source);
        $handle = preg_replace('/^@/', '', (string) $handle);
        $handle = preg_replace('~[/?#].*$~', '', (string) $handle);
        $profile = $handle !== '' ? 'https://x.com/' . rawurlencode($handle) : '';
        return self::baseNetwork(
            'x', 'X', (string) ($cfg['mod_XTitle'] ?? 'X'), $profile, 'Открыть X', 'x.svg',
            self::mapX($feed), self::feedError($feed)
        );
    }

    private static function networkFacebook(array $cfg, mixed $feed): array
    {
        $profile = self::cleanHttpUrl((string) ($cfg['mod_facebookURL'] ?? ''));
        return self::baseNetwork(
            'facebook', 'Facebook', (string) ($cfg['mod_facebookTitle'] ?? 'Facebook'), $profile, 'Открыть Facebook', 'facebook.svg',
            self::mapEntries($feed), self::feedError($feed)
        );
    }

    private static function networkInstagram(array $cfg, mixed $feed): array
    {
        $profile = self::cleanHttpUrl((string) ($cfg['mod_InstagramURL'] ?? ''));
        return self::baseNetwork(
            'instagram', 'Instagram', (string) ($cfg['mod_InstagramTitle'] ?? 'Instagram'), $profile, 'Открыть Instagram', 'instagram.svg',
            self::mapEntries($feed), self::feedError($feed)
        );
    }

    private static function networkYoutube(array $cfg, mixed $feed): array
    {
        $source = trim((string) ($cfg['mod_YoutubeChannel'] ?? ''));
        $profile = '';
        if (is_array($feed) && !empty($feed['channelUrl'])) {
            $profile = (string) $feed['channelUrl'];
        } elseif (preg_match('~^https?://~i', $source)) {
            $profile = self::cleanHttpUrl($source);
        } elseif (str_starts_with($source, '@')) {
            $profile = 'https://www.youtube.com/' . $source;
        } elseif (str_starts_with($source, 'UC')) {
            $profile = 'https://www.youtube.com/channel/' . rawurlencode($source);
        }
        return self::baseNetwork(
            'youtube', 'YouTube', 'YouTube', $profile, 'Открыть YouTube', 'youtube.svg',
            self::mapYoutube($feed), self::feedError($feed)
        );
    }

    private static function networkRss(array $cfg, mixed $feed): array
    {
        $profile = trim((string) ($cfg['mod_RSSID'] ?? ''));
        if ($profile !== '' && !preg_match('~^https?://~i', $profile)) {
            $profile = 'https://' . ltrim($profile, '/');
        }
        return self::baseNetwork(
            'rss', 'RSS', (string) ($cfg['mod_RSSTitle'] ?? 'RSS'), $profile, 'Открыть RSS', 'rss.svg',
            self::mapEntries($feed), self::feedError($feed)
        );
    }

    private static function baseNetwork(
        string $key,
        string $label,
        string $title,
        string $profileUrl,
        string $button,
        string $icon,
        array $items,
        string $error
    ): array {
        return [
            'key' => $key,
            'label' => $label,
            'title' => trim($title) !== '' ? trim($title) : $label,
            'profileUrl' => $profileUrl,
            'button' => $button,
            'icon' => $icon,
            'items' => $items,
            'error' => $error,
        ];
    }

    private static function mapEntries(mixed $feed): array
    {
        if (!is_array($feed)) {
            return [];
        }
        $entries = $feed['responseData']['feed']['entries'] ?? [];
        if (!is_array($entries)) {
            return [];
        }
        $out = [];
        foreach ($entries as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $out[] = [
                'title' => trim((string) ($entry['title'] ?? '')),
                'text' => trim((string) ($entry['content'] ?? '')),
                'image' => trim((string) ($entry['thumb'] ?? '')),
                'url' => trim((string) ($entry['link'] ?? '')),
                'date' => self::formatDate((string) ($entry['publishedDate'] ?? '')),
            ];
        }
        return $out;
    }

    private static function mapYoutube(mixed $feed): array
    {
        if (!is_array($feed) || empty($feed['items']) || !is_array($feed['items'])) {
            return [];
        }
        $out = [];
        foreach ($feed['items'] as $item) {
            $snippet = is_array($item['snippet'] ?? null) ? $item['snippet'] : [];
            $videoId = (string) ($snippet['resourceId']['videoId'] ?? '');
            if ($videoId === '') {
                continue;
            }
            $out[] = [
                'title' => trim((string) ($snippet['title'] ?? '')),
                'text' => trim((string) ($snippet['description'] ?? '')),
                'image' => (string) ($snippet['thumbnails']['medium']['url'] ?? $snippet['thumbnails']['high']['url'] ?? ''),
                'url' => 'https://www.youtube.com/watch?v=' . rawurlencode($videoId),
                'date' => self::formatDate((string) ($snippet['publishedAt'] ?? '')),
            ];
        }
        return $out;
    }

    private static function mapX(mixed $feed): array
    {
        if (!is_array($feed) || empty($feed['items']) || !is_array($feed['items'])) {
            return [];
        }
        $out = [];
        foreach ($feed['items'] as $item) {
            if (!is_array($item)) {
                continue;
            }
            $out[] = [
                'title' => trim((string) ($item['title'] ?? '')),
                'text' => trim((string) ($item['content'] ?? '')),
                'image' => trim((string) ($item['thumb'] ?? '')),
                'url' => trim((string) ($item['link'] ?? '')),
                'date' => self::formatDate((string) ($item['publishedDate'] ?? '')),
            ];
        }
        return $out;
    }

    private static function feedError(mixed $feed): string
    {
        return is_array($feed) ? trim((string) ($feed['error'] ?? '')) : '';
    }

    private static function formatDate(string $value): string
    {
        if ($value === '') {
            return '';
        }
        try {
            $date = new \DateTimeImmutable($value);
            return $date->format('d.m.Y');
        } catch (\Throwable) {
            return '';
        }
    }

    private static function cleanHttpUrl(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }
        if (!preg_match('~^https?://~i', $url)) {
            return 'https://' . ltrim($url, '/');
        }
        return preg_replace('/[#?].*$/', '', $url) ?: '';
    }

    private static function toArray(mixed $value): array
    {
        if ($value instanceof Registry) {
            return $value->toArray();
        }
        if (is_object($value)) {
            return get_object_vars($value);
        }
        return is_array($value) ? $value : [];
    }

    private static function safeLocation(string $value): string
    {
        return in_array($value, ['top-right', 'top-left', 'middle-right', 'middle-left', 'bottom-right', 'bottom-left'], true)
            ? $value
            : 'top-left';
    }

    private static function startIndex(array $networks, string $preferred): int
    {
        foreach ($networks as $index => $network) {
            if ($network['key'] === $preferred) {
                return $index;
            }
        }
        return 0;
    }
}
