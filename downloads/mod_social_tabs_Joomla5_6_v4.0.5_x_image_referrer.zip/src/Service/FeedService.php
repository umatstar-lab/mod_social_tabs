<?php

namespace SocialTabs\Module\SocialTabs\Site\Service;

defined('_JEXEC') or die;

use Joomla\Http\HttpFactory;
use Joomla\Registry\Registry;

final class FeedService
{

    private static function arr($value)
    {
        if (is_object($value)) {
            return get_object_vars($value);
        }
        return is_array($value) ? $value : array();
    }

    private static function social($params, $name)
    {
        $all = self::arr($params->get('show_list_icon'));
        return isset($all[$name]) ? self::arr($all[$name]) : array();
    }

    private static function http($url)
    {
        try {
            $http = HttpFactory::getHttp(array('timeout' => 15));
            $response = $http->get($url, array('User-Agent' => 'Mozilla/5.0 Social-Tabs/1.4.3.3'));
            $code = $response->getStatusCode();
            if ($code >= 200 && $code < 400) {
                return (string) $response->getBody();
            }
        } catch (\Throwable $e) {
            // curl fallback below
        }

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 4,
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_USERAGENT => 'Mozilla/5.0 Social-Tabs/1.4.3.3',
                CURLOPT_SSL_VERIFYPEER => true,
            ));
            $body = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($body !== false && $code >= 200 && $code < 400) {
                return (string) $body;
            }
        }

        return false;
    }

    private static function json($url)
    {
        $raw = self::http($url);
        if ($raw === false || $raw === '') {
            return array('error' => array('message' => 'Сервер сайта не смог получить данные от внешнего API.'));
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : array('error' => array('message' => 'Внешний API вернул некорректный ответ.'));
    }

    private static function error($data)
    {
        if (isset($data['error']['message'])) {
            return (string) $data['error']['message'];
        }
        if (isset($data['error']) && is_string($data['error'])) {
            return $data['error'];
        }
        return '';
    }

    private static function clean_url($url)
    {
        return preg_replace('/[#?].*$/', '', trim((string) $url));
    }

    private static function fb_slug($url)
    {
        $url = self::clean_url($url);
        if ($url === '') {
            return '';
        }
        if (!preg_match('~^https?://~i', $url)) {
            return trim($url, '/@ ');
        }
        $path = (string) parse_url($url, PHP_URL_PATH);
        $bits = array_values(array_filter(explode('/', trim($path, '/'))));
        return isset($bits[0]) ? $bits[0] : '';
    }

    private static function fb_page_match($page, $slug)
    {
        if ($slug === '') {
            return true;
        }
        $slug = strtolower($slug);
        if (!empty($page['username']) && strtolower((string) $page['username']) === $slug) {
            return true;
        }
        if (!empty($page['link']) && strtolower(self::fb_slug($page['link'])) === $slug) {
            return true;
        }
        return false;
    }

    private static function fb_context($facebookUrl, $token, $version)
    {
        $slug = self::fb_slug($facebookUrl);
        $fields = 'id,name,link,username,picture{url},instagram_business_account{id,username}';

        // A Page token: /me resolves directly to the Page.
        $me = self::json('https://graph.facebook.com/' . $version . '/me?fields=' . rawurlencode($fields) . '&access_token=' . rawurlencode($token));
        if (!isset($me['error']) && !empty($me['id']) && self::fb_page_match($me, $slug)) {
            $me['page_access_token'] = $token;
            return array('page' => $me, 'error' => '');
        }

        // A User token: find a managed Page and take its Page Access Token.
        $accountsFields = 'id,name,link,username,access_token,picture{url},instagram_business_account{id,username}';
        $accounts = self::json('https://graph.facebook.com/' . $version . '/me/accounts?fields=' . rawurlencode($accountsFields) . '&limit=100&access_token=' . rawurlencode($token));
        if (!isset($accounts['error']) && !empty($accounts['data'])) {
            foreach ($accounts['data'] as $page) {
                if (self::fb_page_match($page, $slug)) {
                    $page['page_access_token'] = !empty($page['access_token']) ? $page['access_token'] : $token;
                    return array('page' => $page, 'error' => '');
                }
            }
        }

        $err = self::error($me);
        if ($err === '') {
            $err = self::error($accounts);
        }
        if ($err === '') {
            $err = 'Токен не дал доступ к указанной Facebook-странице.';
        }
        return array('page' => array(), 'error' => $err);
    }

    private static function facebook($params, $version)
    {
        $cfg = self::social($params, 'facebook');
        if (!$cfg) {
            return null;
        }
        $url = !empty($cfg['mod_facebookURL']) ? self::clean_url($cfg['mod_facebookURL']) : '';
        $token = !empty($cfg['mod_MetaAccessToken']) ? trim((string) $cfg['mod_MetaAccessToken']) : '';
        $limit = !empty($cfg['mod_facebookLimit']) ? max(1, min(25, (int) $cfg['mod_facebookLimit'])) : 10;

        if ($url === '') {
            return array('responseData' => array('feed' => array('entries' => array())), 'error' => 'Укажи Facebook Page URL.');
        }
        if ($token === '') {
            return array('responseData' => array('feed' => array('entries' => array())), 'error' => 'Для ленты Facebook нужен один Meta Access Token. Кнопка перехода на страницу работает без токена.');
        }

        $ctx = self::fb_context($url, $token, $version);
        if ($ctx['error'] !== '') {
            return array('responseData' => array('feed' => array('entries' => array())), 'error' => $ctx['error']);
        }

        $page = $ctx['page'];
        $pageToken = $page['page_access_token'];
        $fields = 'id,message,story,created_time,full_picture,picture,permalink_url,is_published';
        $feed = self::json('https://graph.facebook.com/' . $version . '/' . rawurlencode((string) $page['id']) . '/feed?fields=' . rawurlencode($fields) . '&limit=' . $limit . '&access_token=' . rawurlencode($pageToken));
        if (isset($feed['error'])) {
            return array('responseData' => array('feed' => array('entries' => array())), 'error' => self::error($feed));
        }

        $entries = array();
        foreach (isset($feed['data']) ? $feed['data'] : array() as $item) {
            if (isset($item['is_published']) && !$item['is_published']) {
                continue;
            }
            $content = isset($item['message']) ? $item['message'] : (isset($item['story']) ? $item['story'] : '');
            $link = !empty($item['permalink_url']) ? $item['permalink_url'] : $url;
            $thumb = !empty($item['full_picture']) ? $item['full_picture'] : (!empty($item['picture']) ? $item['picture'] : null);
            $entries[] = array(
                'pageLink' => !empty($page['link']) ? $page['link'] : $url,
                'pageName' => !empty($page['name']) ? $page['name'] : 'Facebook',
                'link' => $link,
                'content' => $content,
                'thumb' => $thumb,
                'publishedDate' => !empty($item['created_time']) ? $item['created_time'] : '',
            );
        }

        return array('responseData' => array('feed' => array('entries' => $entries)), 'error' => '');
    }

    private static function youtube_channel_id($source)
    {
        $source = trim((string) $source);
        if (preg_match('/\b(UC[a-zA-Z0-9_-]{20,})\b/', $source, $m)) {
            return $m[1];
        }
        if (preg_match('/\b(UU[a-zA-Z0-9_-]{20,})\b/', $source, $m)) {
            return 'UC' . substr($m[1], 2);
        }
        if ($source === '') {
            return '';
        }
        if (strpos($source, '@') === 0) {
            $url = 'https://www.youtube.com/' . $source;
        } elseif (preg_match('~^https?://~i', $source)) {
            $url = self::clean_url($source);
        } else {
            $url = 'https://www.youtube.com/@' . ltrim($source, '@/');
        }
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if (!in_array($host, array('youtube.com', 'www.youtube.com', 'm.youtube.com'), true)) {
            return '';
        }
        $html = self::http($url);
        if (!$html) {
            return '';
        }
        foreach (array('/"channelId":"(UC[a-zA-Z0-9_-]+)"/', '/"externalId":"(UC[a-zA-Z0-9_-]+)"/', '~youtube\.com/channel/(UC[a-zA-Z0-9_-]+)~i') as $pattern) {
            if (preg_match($pattern, $html, $m)) {
                return $m[1];
            }
        }
        return '';
    }

    private static function youtube($params)
    {
        $cfg = self::social($params, 'youtube');
        if (!$cfg) {
            return null;
        }
        $source = isset($cfg['mod_YoutubeChannel']) ? trim((string) $cfg['mod_YoutubeChannel']) : '';
        $limit = !empty($cfg['mod_YoutubeLimit']) ? max(1, min(15, (int) $cfg['mod_YoutubeLimit'])) : 10;
        $channelId = self::youtube_channel_id($source);
        if ($channelId === '') {
            return array('items' => array(), 'error' => 'Не удалось определить YouTube Channel ID.');
        }

        $feedUrl = 'https://www.youtube.com/feeds/videos.xml?channel_id=' . rawurlencode($channelId);
        $xmlText = self::http($feedUrl);
        if (!$xmlText) {
            return array('items' => array(), 'channelId' => $channelId, 'error' => 'Сервер сайта не смог загрузить публичную YouTube RSS-ленту.');
        }
        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($xmlText);
        if (!$xml) {
            return array('items' => array(), 'channelId' => $channelId, 'error' => 'YouTube RSS вернул некорректный XML.');
        }
        $items = array();
        foreach ($xml->entry as $entry) {
            if (count($items) >= $limit) {
                break;
            }
            $yt = $entry->children('http://www.youtube.com/xml/schemas/2015');
            $media = $entry->children('http://search.yahoo.com/mrss/');
            $videoId = isset($yt->videoId) ? (string) $yt->videoId : '';
            if ($videoId === '') {
                continue;
            }
            $desc = '';
            if (isset($media->group) && isset($media->group->description)) {
                $desc = (string) $media->group->description;
            }
            $base = 'https://i.ytimg.com/vi/' . rawurlencode($videoId) . '/';
            $items[] = array('snippet' => array(
                'resourceId' => array('videoId' => $videoId),
                'title' => (string) $entry->title,
                'description' => $desc,
                'publishedAt' => (string) $entry->published,
                'thumbnails' => array(
                    'default' => array('url' => $base . 'default.jpg'),
                    'medium' => array('url' => $base . 'mqdefault.jpg'),
                    'high' => array('url' => $base . 'hqdefault.jpg'),
                ),
            ));
        }
        return array('items' => $items, 'channelId' => $channelId, 'channelUrl' => 'https://www.youtube.com/channel/' . $channelId, 'error' => '');
    }

    private static function instagram_map($items, $username)
    {
        $entries = array();
        foreach ($items as $item) {
            $image = '';
            if (!empty($item['thumbnail_url'])) {
                $image = $item['thumbnail_url'];
            } elseif (!empty($item['media_url'])) {
                $image = $item['media_url'];
            }
            if ($image === '' && !empty($item['children']['data'])) {
                $child = $item['children']['data'][0];
                $image = !empty($child['thumbnail_url']) ? $child['thumbnail_url'] : (!empty($child['media_url']) ? $child['media_url'] : '');
            }
            $entries[] = array(
                'pageLink' => $username !== '' ? 'https://www.instagram.com/' . rawurlencode($username) . '/' : '',
                'pageName' => $username,
                'link' => !empty($item['permalink']) ? $item['permalink'] : '',
                'content' => isset($item['caption']) ? $item['caption'] : '',
                'thumb' => $image,
                'publishedDate' => isset($item['timestamp']) ? $item['timestamp'] : '',
            );
        }
        return $entries;
    }

    private static function instagram($params, $version)
    {
        $ig = self::social($params, 'instagram');
        if (!$ig) {
            return null;
        }
        $fb = self::social($params, 'facebook');
        $url = !empty($ig['mod_InstagramURL']) ? self::clean_url($ig['mod_InstagramURL']) : '';
        $usernameWanted = trim((string) preg_replace('~^.*instagram\.com/([^/?#]+).*$~i', '$1', $url), '/@ ');
        $token = !empty($ig['mod_InstagramAccessToken']) ? trim((string) $ig['mod_InstagramAccessToken']) : (!empty($fb['mod_MetaAccessToken']) ? trim((string) $fb['mod_MetaAccessToken']) : '');
        $limit = !empty($ig['mod_InstagramLimit']) ? max(1, min(25, (int) $ig['mod_InstagramLimit'])) : 10;
        if ($token === '') {
            return array('responseData' => array('feed' => array('entries' => array())), 'error' => 'Для ленты Instagram нужен Meta Access Token. Если Instagram связан с Facebook-страницей, используется тот же токен.');
        }

        $fields = 'id,caption,media_type,media_url,permalink,thumbnail_url,timestamp,username,children{media_type,media_url,permalink,thumbnail_url}';

        // Instagram Login token.
        $me = self::json('https://graph.instagram.com/' . $version . '/me?fields=' . rawurlencode('id,username,account_type') . '&access_token=' . rawurlencode($token));
        if (!isset($me['error'])) {
            $igId = !empty($me['user_id']) ? $me['user_id'] : (!empty($me['id']) ? $me['id'] : 'me');
            $username = !empty($me['username']) ? $me['username'] : $usernameWanted;
            $media = self::json('https://graph.instagram.com/' . $version . '/' . rawurlencode((string) $igId) . '/media?fields=' . rawurlencode($fields) . '&limit=' . $limit . '&access_token=' . rawurlencode($token));
            if (!isset($media['error'])) {
                return array('responseData' => array('feed' => array('entries' => self::instagram_map(isset($media['data']) ? $media['data'] : array(), $username))), 'error' => '');
            }
        }

        // Facebook Page/User token with connected Instagram professional account.
        $fbUrl = !empty($fb['mod_facebookURL']) ? $fb['mod_facebookURL'] : '';
        $ctx = self::fb_context($fbUrl, $token, $version);
        if ($ctx['error'] === '') {
            $page = $ctx['page'];
            $igAccount = !empty($page['instagram_business_account']) ? $page['instagram_business_account'] : array();
            if (!empty($igAccount['id'])) {
                $username = !empty($igAccount['username']) ? $igAccount['username'] : $usernameWanted;
                $pageToken = !empty($page['page_access_token']) ? $page['page_access_token'] : $token;
                $media = self::json('https://graph.facebook.com/' . $version . '/' . rawurlencode((string) $igAccount['id']) . '/media?fields=' . rawurlencode($fields) . '&limit=' . $limit . '&access_token=' . rawurlencode($pageToken));
                if (!isset($media['error'])) {
                    return array('responseData' => array('feed' => array('entries' => self::instagram_map(isset($media['data']) ? $media['data'] : array(), $username))), 'error' => '');
                }
            }
        }

        $err = self::error($me);
        if ($err === '') {
            $err = isset($ctx) ? $ctx['error'] : '';
        }
        if ($err === '') {
            $err = 'Токен не дал доступ к Instagram Professional Account.';
        }
        return array('responseData' => array('feed' => array('entries' => array())), 'error' => $err);
    }

    private static function x_handle($value)
    {
        $value = trim((string) $value);
        $value = preg_replace('~^https?://(?:www\\.)?x\\.com/~i', '', $value);
        $value = preg_replace('/^@/', '', $value);
        $value = preg_replace('~[/?#].*$~', '', $value);
        return preg_replace('/[^A-Za-z0-9_]/', '', $value);
    }

    private static function x_normalize_bearer($bearer)
    {
        $bearer = trim((string) $bearer);
        // Bearer Token is stored as ASCII hex so form serialization cannot alter percent-encoded bytes.
        if (strpos($bearer, 'hex:') === 0) {
            $hex = substr($bearer, 4);
            if ($hex !== '' && ctype_xdigit($hex) && (strlen($hex) % 2) === 0) {
                $decoded = @hex2bin($hex);
                if ($decoded !== false) {
                    $bearer = $decoded;
                }
            }
        }
        // Allow pasting either the raw token or the full "Bearer ..." value.
        $bearer = preg_replace('/^Bearer\s+/i', '', $bearer);
        // Remove invisible characters that can be introduced by copy/paste.
        $bearer = preg_replace('/[\x00-\x20\x7F\x{00A0}\x{200B}\x{200C}\x{200D}\x{FEFF}]+/u', '', $bearer);
        return trim((string) $bearer);
    }

    private static function x_http_once($url, $bearer, &$httpCode = 0)
    {
        $httpCode = 0;
        $body = false;

        // cURL first. It sends the Authorization header exactly as required by X.
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 2,
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_TIMEOUT => 20,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_USERAGENT => 'Social-Tabs/2.0',
                CURLOPT_HTTPHEADER => array(
                    'Authorization: Bearer ' . $bearer,
                    'Accept: application/json'
                ),
            ));
            $body = curl_exec($ch);
            $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
        }

        // Joomla HTTP client only as fallback when cURL is unavailable/failed.
        if ($body === false || $body === '') {
            try {
                $headers = array(
                    'Authorization' => 'Bearer ' . $bearer,
                    'Accept' => 'application/json',
                    'User-Agent' => 'Social-Tabs/2.0'
                );
                $http = HttpFactory::getHttp(array('timeout' => 20));
                $response = $http->get($url, $headers);
                $httpCode = $response->getStatusCode();
                $body = (string) $response->getBody();
            } catch (\Throwable $e) {
                $body = false;
            }
        }

        if ($body === false || $body === '') { return null; }
        $json = json_decode($body, true);
        return is_array($json) ? $json : null;
    }

    private static function x_http_json($url, $bearer, &$httpCode = 0)
    {
        $bearer = self::x_normalize_bearer($bearer);
        $json = self::x_http_once($url, $bearer, $httpCode);

        // Some X bearer tokens are displayed/stored URL-encoded (e.g. %2F, %2B).
        // If the literal token gets 401, retry once with the percent-decoded value.
        if ($httpCode === 401 && preg_match('/%[0-9A-Fa-f]{2}/', $bearer)) {
            $decoded = rawurldecode($bearer);
            if ($decoded !== $bearer && $decoded !== '') {
                $json2 = self::x_http_once($url, $decoded, $code2);
                if ($code2 !== 401) {
                    $httpCode = $code2;
                    return $json2;
                }
            }
        }
        return $json;
    }

    private static function x_error($json, $httpCode)
    {
        if (is_array($json)) {
            if (!empty($json['detail'])) { return (string) $json['detail']; }
            if (!empty($json['title'])) { return (string) $json['title']; }
            if (!empty($json['errors'][0]['detail'])) { return (string) $json['errors'][0]['detail']; }
            if (!empty($json['errors'][0]['message'])) { return (string) $json['errors'][0]['message']; }
        }
        if ($httpCode === 401) { return 'X отклонил Bearer Token (401). Токен сохранён в Joomla, но X считает его недействительным. Проверь, что вставлен именно Bearer Token, а не API Key/Client ID.'; }
        if ($httpCode === 402) { return 'X API требует Credits (402: credits depleted).'; }
        if ($httpCode === 403) { return 'X API вернул 403. Проверь права приложения и токен.'; }
        if ($httpCode === 429) { return 'X API временно ограничил частоту запросов (429).'; }
        return $httpCode ? 'X API вернул HTTP ' . $httpCode . '.' : 'Сервер сайта не смог соединиться с X API.';
    }

    private static function x_media_map($json)
    {
        $map = array();
        if (empty($json['includes']['media']) || !is_array($json['includes']['media'])) { return $map; }
        foreach ($json['includes']['media'] as $m) {
            if (empty($m['media_key'])) { continue; }
            $thumb = '';
            if (!empty($m['url'])) { $thumb = (string) $m['url']; }
            elseif (!empty($m['preview_image_url'])) { $thumb = (string) $m['preview_image_url']; }
            $map[(string) $m['media_key']] = $thumb;
        }
        return $map;
    }

    private static function x_map_posts($json, $handle, $limit)
    {
        $items = array();
        if (empty($json['data']) || !is_array($json['data'])) { return $items; }
        $media = self::x_media_map($json);
        foreach ($json['data'] as $post) {
            if (count($items) >= $limit) { break; }
            if (empty($post['id']) || !isset($post['text'])) { continue; }
            $thumb = '';
            if (!empty($post['attachments']['media_keys']) && is_array($post['attachments']['media_keys'])) {
                foreach ($post['attachments']['media_keys'] as $key) {
                    if (!empty($media[(string) $key])) { $thumb = $media[(string) $key]; break; }
                }
            }
            $items[] = array(
                'id' => (string) $post['id'],
                'link' => 'https://x.com/' . rawurlencode($handle) . '/status/' . rawurlencode((string) $post['id']),
                'title' => '',
                'content' => (string) $post['text'],
                'publishedDate' => !empty($post['created_at']) ? (string) $post['created_at'] : '',
                'thumb' => $thumb,
            );
        }
        return $items;
    }

    private static function x($params, $moduleId = 0)
    {
        $cfg = self::social($params, 'x');
        if (!$cfg) { return null; }

        $xProfile = (string) ($cfg['mod_XProfile'] ?? '');
        $handle = self::x_handle($xProfile);
        if ($handle === '') {
            return array('items' => array(), 'error' => 'Укажи username или ссылку на профиль X.');
        }
        $bearer = !empty($cfg['mod_XBearerToken']) ? self::x_normalize_bearer($cfg['mod_XBearerToken']) : '';
        if ($bearer === '') {
            return array('items' => array(), 'error' => 'Для ленты X нужен Bearer Token из X Developer Console.');
        }
        $xLimit = $cfg['mod_XLimit'] ?? 10;
        $limit = is_numeric($xLimit) ? max(1, min(15, (int) $xLimit)) : 10;
        $cacheHours = isset($cfg['mod_XCacheHours']) && is_numeric($cfg['mod_XCacheHours']) ? max(1, (int) $cfg['mod_XCacheHours']) : 48;
        $cacheTtl = $cacheHours * 3600;
        $staleTtl = max(604800, $cacheTtl * 2);

        // Keep cache separate for each Joomla module instance.
        $moduleId = (int) $moduleId;
        $cacheFile = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'socialtabs_x_api_' . sha1(strtolower($handle) . '|' . $moduleId) . '.json';
        $cached = array();
        if (is_file($cacheFile)) {
            $tmp = json_decode((string) @file_get_contents($cacheFile), true);
            if (is_array($tmp)) { $cached = $tmp; }
        }
        $cachedItems = !empty($cached['items']) && is_array($cached['items']) ? array_values($cached['items']) : array();
        $lastChecked = !empty($cached['checkedAt']) ? (int) $cached['checkedAt'] : (!empty($cached['updated']) ? (int) $cached['updated'] : 0);

        if ($cachedItems && $lastChecked > 0 && (time() - $lastChecked) < $cacheTtl) {
            return array('items' => array_slice($cachedItems, 0, $limit), 'error' => '', 'meta' => array('cached' => true, 'incremental' => true));
        }

        $userId = !empty($cached['userId']) ? (string) $cached['userId'] : '';
        if ($userId === '') {
            $code = 0;
            $user = self::x_http_json('https://api.x.com/2/users/by/username/' . rawurlencode($handle), $bearer, $code);
            if (!is_array($user) || empty($user['data']['id'])) {
                if ($cachedItems && is_file($cacheFile) && (time() - filemtime($cacheFile)) < $staleTtl) {
                    return array('items' => array_slice($cachedItems, 0, $limit), 'error' => '', 'meta' => array('cached' => true, 'stale' => true, 'apiError' => self::x_error($user, $code)));
                }
                $diagToken = self::x_normalize_bearer($bearer);
                $diag = ' [profile request HTTP ' . (int) $code . '; token_len=' . strlen($diagToken) . '; token_sha256=' . substr(hash('sha256', $diagToken), 0, 16) . ']';
                return array('items' => array(), 'error' => self::x_error($user, $code) . $diag);
            }
            $userId = (string) $user['data']['id'];
        }

        $latestId = !empty($cached['latestId']) ? (string) $cached['latestId'] : '';
        if ($latestId === '' && !empty($cachedItems[0]['id'])) { $latestId = (string) $cachedItems[0]['id']; }

        $maxResults = max(5, min(15, $limit));
        $paramsQ = array(
            'max_results' => $maxResults,
            'exclude' => 'replies,retweets',
            'tweet.fields' => 'created_at,attachments',
            'expansions' => 'attachments.media_keys',
            'media.fields' => 'media_key,type,url,preview_image_url,width,height',
        );
        if ($latestId !== '') { $paramsQ['since_id'] = $latestId; }
        $postsUrl = 'https://api.x.com/2/users/' . rawurlencode($userId) . '/tweets?' . http_build_query($paramsQ, '', '&', PHP_QUERY_RFC3986);
        $code = 0;
        $posts = self::x_http_json($postsUrl, $bearer, $code);

        // Some X access configurations reject media expansions while allowing post reads.
        // Retry once with a minimal request so text posts still work instead of showing 403.
        if ($code === 403) {
            $minimal = array('max_results' => $maxResults, 'exclude' => 'replies,retweets', 'tweet.fields' => 'created_at');
            if ($latestId !== '') { $minimal['since_id'] = $latestId; }
            $postsUrl = 'https://api.x.com/2/users/' . rawurlencode($userId) . '/tweets?' . http_build_query($minimal, '', '&', PHP_QUERY_RFC3986);
            $posts = self::x_http_json($postsUrl, $bearer, $code);
        }

        if ($code >= 200 && $code < 300 && is_array($posts)) {
            $newItems = self::x_map_posts($posts, $handle, $maxResults);
            if ($latestId === '') {
                $merged = $newItems;
            } else {
                $merged = array();
                $seen = array();
                foreach (array_merge($newItems, $cachedItems) as $item) {
                    if (empty($item['id'])) { continue; }
                    $id = (string) $item['id'];
                    if (isset($seen[$id])) { continue; }
                    $seen[$id] = true;
                    $merged[] = $item;
                }
            }
            $merged = array_slice($merged, 0, max(15, $limit));
            $state = array(
                'items' => $merged,
                'userId' => $userId,
                'latestId' => !empty($merged[0]['id']) ? (string) $merged[0]['id'] : $latestId,
                'checkedAt' => time(),
                'updated' => !empty($newItems) ? time() : (!empty($cached['updated']) ? (int) $cached['updated'] : time()),
            );
            @file_put_contents($cacheFile, json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
            if ($merged) {
                return array('items' => array_slice($merged, 0, $limit), 'error' => '', 'meta' => array('cached' => false, 'incremental' => ($latestId !== ''), 'newCount' => count($newItems)));
            }
            return array('items' => array(), 'error' => 'В профиле X нет доступных публикаций для отображения.');
        }

        if ($cachedItems && is_file($cacheFile) && (time() - filemtime($cacheFile)) < $staleTtl) {
            return array('items' => array_slice($cachedItems, 0, $limit), 'error' => '', 'meta' => array('cached' => true, 'stale' => true, 'apiError' => self::x_error($posts, $code)));
        }
        return array('items' => array(), 'error' => self::x_error($posts, $code) . ' [posts request HTTP ' . (int) $code . ']');
    }


    private static function rss(Registry $params): ?array
    {
        $cfg = self::social($params, 'rss');
        if (!$cfg) { return null; }
        $source = trim((string) ($cfg['mod_RSSID'] ?? ''));
        $limit = max(1, min(25, (int) ($cfg['mod_RSSLimit'] ?? 10)));
        if ($source === '') {
            return ['responseData' => ['feed' => ['entries' => []]], 'error' => 'Укажи URL RSS/Atom-ленты.'];
        }
        if (!preg_match('~^https?://~i', $source)) { $source = 'https://' . ltrim($source, '/'); }
        $raw = self::http($source);
        if ($raw === false || $raw === '') {
            return ['responseData' => ['feed' => ['entries' => []]], 'error' => 'Не удалось загрузить RSS/Atom-ленту.'];
        }
        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($raw, 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NONET);
        if (!$xml) {
            return ['responseData' => ['feed' => ['entries' => []]], 'error' => 'RSS/Atom вернул некорректный XML.'];
        }
        $entries = [];
        if (isset($xml->channel->item)) {
            foreach ($xml->channel->item as $item) {
                if (count($entries) >= $limit) break;
                $description = trim((string) ($item->description ?? ''));
                $image = '';
                if (preg_match('~<img[^>]+src=["\']([^"\']+)~i', $description, $m)) { $image = $m[1]; }
                $entries[] = [
                    'pageLink' => $source,
                    'pageName' => (string) ($xml->channel->title ?? 'RSS'),
                    'link' => trim((string) ($item->link ?? $item->guid ?? '')),
                    'title' => trim((string) ($item->title ?? '')),
                    'content' => trim(strip_tags($description)),
                    'thumb' => $image,
                    'publishedDate' => trim((string) ($item->pubDate ?? '')),
                ];
            }
        } else {
            $ns = $xml->getNamespaces(true);
            foreach ($xml->entry as $item) {
                if (count($entries) >= $limit) break;
                $link = '';
                foreach ($item->link as $ln) {
                    $a = $ln->attributes();
                    if (!empty($a['href'])) { $link = (string) $a['href']; break; }
                }
                $content = trim((string) ($item->content ?? $item->summary ?? ''));
                $entries[] = [
                    'pageLink' => $source,
                    'pageName' => (string) ($xml->title ?? 'RSS'),
                    'link' => $link,
                    'title' => trim((string) ($item->title ?? '')),
                    'content' => trim(strip_tags($content)),
                    'thumb' => '',
                    'publishedDate' => trim((string) ($item->updated ?? $item->published ?? '')),
                ];
            }
        }
        return ['responseData' => ['feed' => ['entries' => $entries]], 'error' => ''];
    }


    private static function cached(string $type, $params, int $moduleId, int $ttl, callable $producer): mixed
    {
        $cfg = self::social($params, $type);
        if (!$cfg) { return null; }
        $fingerprint = hash('sha256', json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $file = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR
            . 'socialtabs_' . $type . '_' . $moduleId . '_' . substr($fingerprint, 0, 16) . '.json';

        if (is_file($file) && (time() - filemtime($file)) < $ttl) {
            $cached = json_decode((string) file_get_contents($file), true);
            if (is_array($cached)) { return $cached; }
        }

        $fresh = $producer();
        if (is_array($fresh) && empty($fresh['error'])) {
            @file_put_contents($file, json_encode($fresh, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
            return $fresh;
        }

        if (is_file($file) && (time() - filemtime($file)) < 86400) {
            $cached = json_decode((string) file_get_contents($file), true);
            if (is_array($cached)) { return $cached; }
        }

        return $fresh;
    }

    public static function prefetch($params, $moduleId = 0)
    {
        $version = 'v26.0';
        $out = array();
        $fb = self::cached('facebook', $params, (int) $moduleId, 900, fn() => self::facebook($params, $version));
        if ($fb !== null) { $out['facebook'] = $fb; }

        $yt = self::cached('youtube', $params, (int) $moduleId, 1800, fn() => self::youtube($params));
        if ($yt !== null) { $out['youtube'] = $yt; }

        $ig = self::cached('instagram', $params, (int) $moduleId, 900, fn() => self::instagram($params, $version));
        if ($ig !== null) { $out['instagram'] = $ig; }
        $x = self::x($params, $moduleId);
        if ($x !== null) {
            $out['x'] = $x;
        }
        $rss = self::cached('rss', $params, (int) $moduleId, 1800, fn() => self::rss($params));
        if ($rss !== null) { $out['rss'] = $rss; }
        return $out;
    }
}
