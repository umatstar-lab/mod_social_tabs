<?php

namespace SocialTabs\Module\SocialTabs\Site\Field;

defined('_JEXEC') or die;

use Joomla\CMS\Form\FormField;
use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;

final class SocialtabsField extends FormField
{
    protected $type = 'Socialtabs';

    private const SUPPORTED = [
        'x' => ['label' => 'X', 'icon' => 'x.svg'],
        'facebook' => ['label' => 'Facebook', 'icon' => 'facebook.svg'],
        'instagram' => ['label' => 'Instagram', 'icon' => 'instagram.svg'],
        'youtube' => ['label' => 'YouTube', 'icon' => 'youtube.svg'],
        'rss' => ['label' => 'RSS', 'icon' => 'rss.svg'],
    ];

    protected function getInput(): string
    {
        $app = \Joomla\CMS\Factory::getApplication();
        $document = $app->getDocument();
        $assets = $document->getWebAssetManager();
        $base = rtrim(Uri::root(true), '/') . '/media/mod_social_tabs';
        // WebAssetManager paths are relative to /media; image URLs below are site-relative.
        if (!$assets->assetExists('style', 'mod_social_tabs.admin')) {
            $assets->registerStyle('mod_social_tabs.admin', 'mod_social_tabs/admin.css', ['version' => '4.0.4']);
        }
        if (!$assets->assetExists('script', 'mod_social_tabs.admin')) {
            $assets->registerScript('mod_social_tabs.admin', 'mod_social_tabs/admin.js', ['version' => '4.0.4'], ['defer' => true]);
        }
        $assets->useStyle('mod_social_tabs.admin');
        $assets->useScript('mod_social_tabs.admin');

        // Guaranteed JavaScript fallback: execute the same module script inline.
        // This protects the custom field from template/WAM asset suppression.
        $jsFile = JPATH_ROOT . '/media/mod_social_tabs/js/admin.js';
        if (is_file($jsFile)) {
            $js = (string) file_get_contents($jsFile);
            if ($js !== '') {
                $assets->addInlineScript($js, ['name' => 'mod_social_tabs.admin.inline']);
            }
        }

        // Guaranteed style fallback for Joomla 5/6 administrator templates.
        // The CSS is fully scoped to .socialtabs-admin-social, so it cannot affect other fields.
        $cssFile = JPATH_ROOT . '/media/mod_social_tabs/css/admin.css';
        if (is_file($cssFile)) {
            $css = (string) file_get_contents($cssFile);
            if ($css !== '') {
                $assets->addInlineStyle($css, ['name' => 'mod_social_tabs.admin.inline']);
            }
        }

        $value = $this->toArray($this->value);
        $id = htmlspecialchars($this->id, ENT_QUOTES, 'UTF-8');
        $name = htmlspecialchars($this->name, ENT_QUOTES, 'UTF-8');
        $baseIcon = $base . '/images/';

        $html = '<div class="socialtabs-admin-social" id="' . $id . '-editor" data-field-name="' . $name . '">';
        $html .= '<button type="button" class="btn btn-primary socialtabs-add-toggle">Добавить соцсеть</button>';
        $html .= '<div class="socialtabs-social-picker" hidden>';
        foreach (self::SUPPORTED as $key => $meta) {
            $html .= '<button type="button" class="socialtabs-picker-item" data-social="' . $key . '" data-label="' . htmlspecialchars($meta['label'], ENT_QUOTES, 'UTF-8') . '">'
                . '<img src="' . htmlspecialchars($baseIcon . $meta['icon'], ENT_QUOTES, 'UTF-8') . '" alt="">'
                . '<span data-picker-label>' . htmlspecialchars($meta['label'], ENT_QUOTES, 'UTF-8') . '</span></button>';
        }
        $html .= '</div>';
        $html .= '<div class="socialtabs-social-list">';
        foreach (array_keys($value) as $key) {
            if (!isset(self::SUPPORTED[$key])) {
                continue;
            }
            $html .= $this->renderCard($key, $this->toArray($value[$key]), $baseIcon, $this->name);
        }
        $html .= '</div>';
        foreach (self::SUPPORTED as $key => $meta) {
            $html .= '<template data-social-template="' . $key . '">' . $this->renderCard($key, [], $baseIcon, $this->name) . '</template>';
        }
        $html .= '<p class="socialtabs-admin-note">Поддерживаются только актуальные интеграции: X API v2, Meta Graph/Instagram API, YouTube Atom/RSS и обычные RSS/Atom-ленты. Устаревшие и неподдерживаемые интеграции удалены.</p>';
        $html .= '</div>';
        return $html;
    }

    private function renderCard(string $key, array $cfg, string $baseIcon, string $fieldName): string
    {
        $meta = self::SUPPORTED[$key];
        $name = $fieldName . '[' . $key . ']';
        $icon = htmlspecialchars($baseIcon . $meta['icon'], ENT_QUOTES, 'UTF-8');
        $label = htmlspecialchars($meta['label'], ENT_QUOTES, 'UTF-8');

        $accordionName = 'socialtabs-accordion-' . substr(sha1($fieldName), 0, 10);
        $html = '<details class="socialtabs-card socialtabs-network-' . $key . '" data-social-card="' . $key . '" name="' . $accordionName . '" draggable="true">';
        $html .= '<summary class="socialtabs-card__header">'
            . '<span class="socialtabs-drag" title="Перетащить">⋮⋮</span>'
            . '<img src="' . $icon . '" alt=""><strong>' . $label . '</strong>'
            . '<span class="socialtabs-card-chevron" aria-hidden="true">▸</span>'
            . '<button type="button" class="socialtabs-card-remove" aria-label="Удалить" title="Удалить">×</button>'
            . '</summary><div class="socialtabs-card__body">';

        if ($key === 'x') {
            $html .= $this->text($name . '[mod_XProfile]', $cfg['mod_XProfile'] ?? '', 'X profile', '@username, username или https://x.com/username');
            $html .= $this->text($name . '[mod_XTitle]', $cfg['mod_XTitle'] ?? 'X', 'Title', 'Заголовок вкладки.');
            $html .= $this->number($name . '[mod_XLimit]', $cfg['mod_XLimit'] ?? 10, 'Limit', 1, 15);
            $html .= $this->xToken($name . '[mod_XBearerToken]', $cfg['mod_XBearerToken'] ?? '');
            $html .= $this->number($name . '[mod_XCacheHours]', $cfg['mod_XCacheHours'] ?? 48, 'Интервал обновления X, часов', 1, null);
            $html .= '<small>После первой загрузки X обновляется через <code>since_id</code> и получает только новые публикации.</small>';
        } elseif ($key === 'facebook') {
            $html .= $this->text($name . '[mod_facebookURL]', $cfg['mod_facebookURL'] ?? '', 'Facebook Page URL', 'Например: https://www.facebook.com/jmhum.org');
            $html .= $this->text($name . '[mod_facebookTitle]', $cfg['mod_facebookTitle'] ?? 'Facebook', 'Title', 'Заголовок вкладки.');
            $html .= $this->password($name . '[mod_MetaAccessToken]', $cfg['mod_MetaAccessToken'] ?? '', 'Meta Access Token', 'Токен остаётся только на сервере.');
            $html .= $this->number($name . '[mod_facebookLimit]', $cfg['mod_facebookLimit'] ?? 10, 'Limit', 1, 25);
        } elseif ($key === 'instagram') {
            $html .= $this->text($name . '[mod_InstagramURL]', $cfg['mod_InstagramURL'] ?? '', 'Instagram URL', 'Например: https://www.instagram.com/museum_jewish_memory_holocaust/');
            $html .= $this->text($name . '[mod_InstagramTitle]', $cfg['mod_InstagramTitle'] ?? 'Instagram', 'Title', 'Заголовок вкладки.');
            $html .= $this->password($name . '[mod_InstagramAccessToken]', $cfg['mod_InstagramAccessToken'] ?? '', 'Instagram Access Token', 'Если поле пустое, модуль может использовать Meta Access Token из Facebook.');
            $html .= $this->number($name . '[mod_InstagramLimit]', $cfg['mod_InstagramLimit'] ?? 10, 'Limit', 1, 25);
        } elseif ($key === 'youtube') {
            $html .= $this->text($name . '[mod_YoutubeChannel]', $cfg['mod_YoutubeChannel'] ?? '', 'YouTube Channel', 'Ссылка, @handle или Channel ID (UC...). API Key не нужен.');
            $html .= $this->number($name . '[mod_YoutubeLimit]', $cfg['mod_YoutubeLimit'] ?? 10, 'Limit', 1, 15);
        } elseif ($key === 'rss') {
            $html .= $this->text($name . '[mod_RSSID]', $cfg['mod_RSSID'] ?? '', 'RSS/Atom URL', 'Полный URL RSS или Atom-ленты.');
            $html .= $this->text($name . '[mod_RSSTitle]', $cfg['mod_RSSTitle'] ?? 'RSS', 'Title', 'Заголовок вкладки.');
            $html .= $this->number($name . '[mod_RSSLimit]', $cfg['mod_RSSLimit'] ?? 10, 'Limit', 1, 25);
        }

        $html .= '</div></details>';
        return $html;
    }

    private function text(string $name, mixed $value, string $label, string $help = ''): string
    {
        return $this->input('text', $name, (string) $value, $label, $help);
    }

    private function password(string $name, mixed $value, string $label, string $help = ''): string
    {
        return $this->input('password', $name, (string) $value, $label, $help, 'autocomplete="off"');
    }

    private function number(string $name, mixed $value, string $label, int $min, ?int $max): string
    {
        $extra = 'min="' . $min . '" step="1"' . ($max !== null ? ' max="' . $max . '"' : '');
        return $this->input('number', $name, (string) $value, $label, '', $extra);
    }

    private function input(string $type, string $name, string $value, string $label, string $help = '', string $extra = ''): string
    {
        $html = '<label class="socialtabs-field"><span>' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</span>';
        $html .= '<input class="form-control" type="' . $type . '" name="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '" ' . $extra . '>';
        if ($help !== '') {
            $html .= '<small>' . htmlspecialchars($help, ENT_QUOTES, 'UTF-8') . '</small>';
        }
        return $html . '</label>';
    }

    private function xToken(string $name, mixed $stored): string
    {
        $stored = (string) $stored;
        $raw = $stored;
        if (str_starts_with($stored, 'hex:')) {
            $hex = substr($stored, 4);
            if ($hex !== '' && ctype_xdigit($hex) && strlen($hex) % 2 === 0) {
                $decoded = hex2bin($hex);
                if ($decoded !== false) {
                    $raw = $decoded;
                }
            } else {
                $raw = '';
            }
        }
        $hidden = $raw !== '' ? 'hex:' . bin2hex($raw) : '';
        return '<label class="socialtabs-field"><span>X Bearer Token</span>'
            . '<input type="hidden" class="socialtabs-x-token-store" name="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars($hidden, ENT_QUOTES, 'UTF-8') . '">'
            . '<input class="form-control socialtabs-x-token" type="password" autocomplete="off" value="' . htmlspecialchars($raw, ENT_QUOTES, 'UTF-8') . '">'
            . '<small>Хранится в HEX-виде, чтобы Joomla не меняла символы Bearer Token.</small></label>';
    }

    private function toArray(mixed $value): array
    {
        if ($value instanceof Registry) {
            return $value->toArray();
        }
        if (is_object($value)) {
            return get_object_vars($value);
        }
        return is_array($value) ? $value : [];
    }
}
