<?php

namespace SocialTabs\Module\SocialTabs\Site\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use SocialTabs\Module\SocialTabs\Site\Helper\SocialTabsHelper;

final class Dispatcher extends AbstractModuleDispatcher
{
    protected function getLayoutData(): array
    {
        $data = parent::getLayoutData();

        $data['viewModel'] = SocialTabsHelper::buildViewModel(
            $data['params'],
            (int) $data['module']->id
        );

        $document = $this->getApplication()->getDocument();
        $wa = $document->getWebAssetManager();
        // WebAssetManager adds the media and css/js folders when resolving local paths.
        $base = 'mod_social_tabs';

        if (!$wa->assetExists('style', 'mod_social_tabs.site')) {
            $wa->registerStyle('mod_social_tabs.site', $base . '/social-tabs.css', ['version' => '4.0.5']);
        }
        if (!$wa->assetExists('script', 'mod_social_tabs.site')) {
            $wa->registerScript('mod_social_tabs.site', $base . '/social-tabs.js', ['version' => '4.0.5'], ['defer' => true]);
        }

        $wa->useStyle('mod_social_tabs.site');
        $wa->useScript('mod_social_tabs.site');

        // Guaranteed JavaScript fallback. If a template/plugin suppresses the external
        // WebAsset script, the widget still initializes and displays its active feed.
        $jsFile = JPATH_ROOT . '/media/mod_social_tabs/js/social-tabs.js';
        if (is_file($jsFile)) {
            $js = (string) file_get_contents($jsFile);
            if ($js !== '') {
                $wa->addInlineScript($js, ['name' => 'mod_social_tabs.site.inline']);
            }
        }

        // Some Joomla/admin/template stacks may suppress a dynamically registered stylesheet.
        // Keep the external asset for caching, but also inject the small module stylesheet inline
        // so the widget cannot render unstyled. This is isolated to .socialtabs-social-tabs selectors.
        $cssFile = JPATH_ROOT . '/media/mod_social_tabs/css/social-tabs.css';
        if (is_file($cssFile)) {
            $css = (string) file_get_contents($cssFile);
            if ($css !== '') {
                $wa->addInlineStyle($css, ['name' => 'mod_social_tabs.site.inline']);
            }
        }

        return $data;
    }
}
