<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;

return new class () implements InstallerScriptInterface {
    protected $minimumPhp = '8.1.0';
    protected $minimumJoomla = '5.0.0';

    public function install(InstallerAdapter $parent): bool { return true; }
    public function update(InstallerAdapter $parent): bool { return true; }
    public function uninstall(InstallerAdapter $parent): bool { return true; }

    public function preflight(string $type, InstallerAdapter $parent): bool
    {
        if (version_compare(PHP_VERSION, $this->minimumPhp, '<')) {
            Factory::getApplication()->enqueueMessage(sprintf(Text::_('JLIB_INSTALLER_MINIMUM_PHP'), $this->minimumPhp), 'error');
            return false;
        }
        if (version_compare(JVERSION, $this->minimumJoomla, '<') || version_compare(JVERSION, '7.0.0', '>=')) {
            Factory::getApplication()->enqueueMessage('Social Tabs поддерживает Joomla 5.x и 6.x.', 'error');
            return false;
        }
        return true;
    }

    public function postflight(string $type, InstallerAdapter $parent): bool { return true; }
};
