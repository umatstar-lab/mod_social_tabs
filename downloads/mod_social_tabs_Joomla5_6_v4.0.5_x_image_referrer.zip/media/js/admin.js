(() => {
    'use strict';
    if (window.__socialTabsAdmin25) return;
    window.__socialTabsAdmin25 = true;

    const utf8Hex = (value) => [...new TextEncoder().encode(value)]
        .map((b) => b.toString(16).padStart(2, '0')).join('');

    const refreshPicker = (root) => {
        const list = root.querySelector('.socialtabs-social-list');
        if (!list) return;
        const active = new Set([...list.querySelectorAll('[data-social-card]')]
            .map((el) => el.dataset.socialCard));
        root.querySelectorAll('.socialtabs-picker-item').forEach((button) => {
            const key = button.dataset.social || '';
            const used = active.has(key);
            const label = button.dataset.label || key;
            const labelNode = button.querySelector('[data-picker-label]');
            button.disabled = used;
            button.hidden = false;
            button.classList.toggle('is-added', used);
            if (labelNode) labelNode.textContent = used ? `${label} — добавлено` : label;
        });
    };

    const syncToken = (card) => {
        const token = card?.querySelector('.socialtabs-x-token');
        const store = card?.querySelector('.socialtabs-x-token-store');
        if (token && store) store.value = token.value ? `hex:${utf8Hex(token.value)}` : '';
    };

    const closeOtherCards = (root, current) => {
        root.querySelectorAll('details[data-social-card][open]').forEach((card) => {
            if (card !== current) card.removeAttribute('open');
        });
    };

    const init = (root) => {
        if (!root || root.dataset.socialtabsInitialized === '1') return;
        root.dataset.socialtabsInitialized = '1';

        const picker = root.querySelector('.socialtabs-social-picker');
        const list = root.querySelector('.socialtabs-social-list');
        if (!picker || !list) return;
        let dragged = null;

        // Start as a compact accordion: all stored cards collapsed.
        list.querySelectorAll('details[data-social-card]').forEach((card) => card.removeAttribute('open'));

        root.addEventListener('click', (event) => {
            const add = event.target.closest('.socialtabs-add-toggle');
            if (add && root.contains(add)) {
                event.preventDefault();
                picker.hidden = !picker.hidden;
                return;
            }

            const pick = event.target.closest('.socialtabs-picker-item');
            if (pick && root.contains(pick)) {
                event.preventDefault();
                if (pick.disabled) return;
                const key = pick.dataset.social || '';
                if (!key || list.querySelector(`[data-social-card="${CSS.escape(key)}"]`)) return;
                const tpl = root.querySelector(`template[data-social-template="${CSS.escape(key)}"]`);
                if (!tpl) return;
                const fragment = tpl.content.cloneNode(true);
                const card = fragment.querySelector('[data-social-card]');
                list.appendChild(fragment);
                closeOtherCards(root, card);
                card?.setAttribute('open', '');
                picker.hidden = true;
                refreshPicker(root);
                card?.scrollIntoView({behavior: 'smooth', block: 'nearest'});
                return;
            }

            const remove = event.target.closest('.socialtabs-card-remove');
            if (remove && root.contains(remove)) {
                event.preventDefault();
                event.stopPropagation();
                remove.closest('[data-social-card]')?.remove();
                refreshPicker(root);
            }
        });

        root.addEventListener('toggle', (event) => {
            const card = event.target.closest?.('details[data-social-card]');
            if (card && card.open) closeOtherCards(root, card);
        }, true);

        root.addEventListener('input', (event) => {
            if (event.target.matches('.socialtabs-x-token')) syncToken(event.target.closest('[data-social-card]'));
        });
        root.addEventListener('change', (event) => {
            if (event.target.matches('.socialtabs-x-token')) syncToken(event.target.closest('[data-social-card]'));
        });

        root.addEventListener('dragstart', (event) => {
            const card = event.target.closest('[data-social-card]');
            if (!card || !root.contains(card)) return;
            if (!event.target.closest('.socialtabs-drag')) {
                event.preventDefault();
                return;
            }
            dragged = card;
            card.classList.add('is-dragging');
            if (event.dataTransfer) event.dataTransfer.effectAllowed = 'move';
        });
        root.addEventListener('dragend', () => {
            dragged?.classList.remove('is-dragging');
            dragged = null;
        });
        list.addEventListener('dragover', (event) => {
            if (!dragged) return;
            event.preventDefault();
            const cards = [...list.querySelectorAll('[data-social-card]:not(.is-dragging)')];
            const next = cards.find((card) => event.clientY < card.getBoundingClientRect().top + card.offsetHeight / 2);
            list.insertBefore(dragged, next || null);
        });

        root.closest('form')?.addEventListener('submit', () => {
            root.querySelectorAll('[data-social-card]').forEach(syncToken);
        });

        refreshPicker(root);
    };

    const boot = (scope = document) => scope.querySelectorAll?.('.socialtabs-admin-social').forEach(init);
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => boot(), {once: true});
    else boot();
    document.addEventListener('joomla:updated', (event) => boot(event.target || document));

    const observer = new MutationObserver((records) => {
        for (const record of records) for (const node of record.addedNodes) {
            if (node.nodeType !== 1) continue;
            if (node.matches?.('.socialtabs-admin-social')) init(node);
            boot(node);
        }
    });
    observer.observe(document.documentElement, {childList: true, subtree: true});
})();
