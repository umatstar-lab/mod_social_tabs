(() => {
    'use strict';

    // Versioned guard. Do not reuse the old guard name: browsers can keep an older
    // external asset in cache after an extension update.
    if (window.__socialTabsFront27) return;
    window.__socialTabsFront27 = true;

    const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

    const waitTransition = (node, duration) => new Promise((resolve) => {
        let done = false;
        const finish = () => {
            if (done) return;
            done = true;
            node.removeEventListener('transitionend', onEnd);
            resolve();
        };
        const onEnd = (event) => {
            if (event.target === node && event.propertyName === 'transform') finish();
        };
        node.addEventListener('transitionend', onEnd);
        window.setTimeout(finish, duration + 120);
    });

    class SocialTabs {
        constructor(root) {
            this.root = root;
            this.tabs = [...root.querySelectorAll('[data-tab-index]')];
            this.panels = [...root.querySelectorAll('[data-panel-index]')];
            this.shell = root.querySelector('.socialtabs-social-tabs__shell');
            this.controls = root.querySelector('.socialtabs-social-tabs__controls');
            this.method = root.dataset.method === 'static' ? 'static' : 'slide';
            this.position = root.dataset.position === 'absolute' ? 'absolute' : 'fixed';
            this.location = root.dataset.location || 'top-left';
            this.offset = Math.max(0, Number.parseInt(root.dataset.offset || '20', 10) || 0);
            this.width = clamp(Number.parseInt(root.dataset.width || '500', 10) || 500, 260, 900);
            this.height = clamp(Number.parseInt(root.dataset.height || '700', 10) || 700, 260, 1200);
            this.start = clamp(Number.parseInt(root.dataset.start || '0', 10) || 0, 0, Math.max(0, this.panels.length - 1));
            this.loadOpen = root.dataset.loadOpen === '1';
            this.autoClose = root.dataset.autoClose === '1';
            this.open = this.method === 'static';
            this.paused = false;
            this.rotating = false;
            this.rotateDelay = 6000;
            this.rotateDuration = 600;
            this.rotateTimer = 0;

            this.applyGeometry();
            this.bind();
            this.activate(this.start, this.loadOpen || this.method === 'static');
            this.startRotation();
        }

        applyGeometry() {
            this.root.style.setProperty('--socialtabs-width', `${this.width}px`);
            this.root.style.setProperty('--socialtabs-height', `${this.height}px`);
            this.root.style.setProperty('--socialtabs-offset', `${this.offset}px`);
            this.root.dataset.side = this.location.includes('right') ? 'right' : 'left';
            this.root.dataset.vertical = this.location.startsWith('bottom') ? 'bottom' : (this.location.startsWith('middle') ? 'middle' : 'top');
            if (this.method === 'slide') this.root.style.position = this.position;
        }

        bind() {
            this.tabs.forEach((tab, index) => {
                tab.addEventListener('click', (event) => {
                    event.stopPropagation();
                    const same = index === this.activeIndex && this.open;
                    if (same && this.method === 'slide') this.close();
                    else this.activate(index, true);
                });
            });

            this.controls?.addEventListener('click', (event) => {
                const button = event.target.closest('button[data-action]');
                if (!button) return;
                event.stopPropagation();
                const action = button.dataset.action;
                if (action === 'close') this.close();
                if (action === 'up') this.manualRotate('up');
                if (action === 'down') this.manualRotate('down');
                if (action === 'pause') {
                    this.paused = !this.paused;
                    button.classList.toggle('is-active', this.paused);
                    button.textContent = this.paused ? '▶' : 'Ⅱ';
                    button.title = this.paused ? 'Продолжить' : 'Пауза';
                    if (this.paused) this.stopRotation();
                    else this.startRotation();
                }
            });

            if (this.autoClose && this.method === 'slide') {
                document.addEventListener('click', (event) => {
                    if (this.open && !this.root.contains(event.target)) this.close();
                });
            }

            window.addEventListener('resize', () => this.applyGeometry(), {passive: true});
            document.addEventListener('visibilitychange', () => {
                if (document.hidden) this.stopRotation();
                else if (!this.paused) this.startRotation();
            });
        }

        activate(index, open = true) {
            this.activeIndex = index;
            this.tabs.forEach((tab, i) => {
                const active = i === index;
                tab.classList.toggle('is-active', active);
                tab.setAttribute('aria-selected', active ? 'true' : 'false');
            });
            this.panels.forEach((panel, i) => { panel.hidden = i !== index; });
            if (open) this.show();
            if (!this.paused) this.startRotation();
        }

        show() {
            this.open = true;
            this.root.classList.add('is-open');
        }

        close() {
            if (this.method === 'static') return;
            this.open = false;
            this.root.classList.remove('is-open');
        }

        getActiveStream() {
            return this.panels[this.activeIndex]?.querySelector('.socialtabs-social-tabs__stream') || null;
        }

        getPosts(stream) {
            return [...(stream?.children || [])].filter((node) => node.classList?.contains('socialtabs-social-tabs__post'));
        }

        stopRotation() {
            if (this.rotateTimer) {
                window.clearTimeout(this.rotateTimer);
                this.rotateTimer = 0;
            }
        }

        startRotation() {
            this.stopRotation();
            if (this.paused || document.hidden) return;
            const stream = this.getActiveStream();
            if (this.getPosts(stream).length < 2) return;

            this.rotateTimer = window.setTimeout(async () => {
                // Same direction as the legacy module: the last item enters from above.
                await this.rotate('down');
                if (!this.paused) this.startRotation();
            }, this.rotateDelay);
        }

        manualRotate(direction) {
            this.stopRotation();
            this.rotate(direction).then(() => {
                if (!this.paused) this.startRotation();
            });
        }

        async rotate(direction = 'down') {
            if (this.rotating) return;
            const stream = this.getActiveStream();
            const posts = this.getPosts(stream);
            if (!stream || posts.length < 2) return;

            this.rotating = true;
            try {
                stream.style.willChange = 'transform';
                stream.style.transition = 'none';

                if (direction === 'up') {
                    const first = posts[0];
                    const style = window.getComputedStyle(first);
                    const distance = first.getBoundingClientRect().height + (parseFloat(style.marginBottom) || 0);
                    if (distance <= 0) return;

                    stream.style.transform = 'translate3d(0,0,0)';
                    // Force layout so the browser always sees a real start/end state.
                    void stream.offsetHeight;
                    stream.style.transition = `transform ${this.rotateDuration}ms linear`;
                    stream.style.transform = `translate3d(0,-${distance}px,0)`;
                    await waitTransition(stream, this.rotateDuration);

                    stream.style.transition = 'none';
                    stream.append(first);
                    stream.style.transform = 'translate3d(0,0,0)';
                    void stream.offsetHeight;
                } else {
                    const last = posts[posts.length - 1];
                    stream.prepend(last);
                    const style = window.getComputedStyle(last);
                    const distance = last.getBoundingClientRect().height + (parseFloat(style.marginBottom) || 0);
                    if (distance <= 0) return;

                    stream.style.transform = `translate3d(0,-${distance}px,0)`;
                    void stream.offsetHeight;
                    stream.style.transition = `transform ${this.rotateDuration}ms linear`;
                    stream.style.transform = 'translate3d(0,0,0)';
                    await waitTransition(stream, this.rotateDuration);

                    stream.style.transition = 'none';
                    stream.style.transform = 'translate3d(0,0,0)';
                }
            } finally {
                stream.style.willChange = '';
                this.rotating = false;
            }
        }
    }

    const sanitizePost = (post) => {
        if (!post) return;
        [...post.children].forEach((node) => {
            if (!node.classList?.contains('socialtabs-social-tabs__post-link') &&
                !node.classList?.contains('socialtabs-social-tabs__post-footer')) node.remove();
        });
        const link = post.querySelector(':scope > .socialtabs-social-tabs__post-link');
        if (link) {
            [...link.children].forEach((node) => {
                if (!node.classList?.contains('socialtabs-social-tabs__post-image') &&
                    !node.classList?.contains('socialtabs-social-tabs__post-copy')) node.remove();
            });
        }
        post.querySelectorAll('[title],[aria-label]').forEach((node) => {
            if (node.closest('.socialtabs-social-tabs__profiles')) return;
            const hint = `${node.getAttribute('title') || ''} ${node.getAttribute('aria-label') || ''}`.toLowerCase();
            if (hint.includes('direct link') || hint.includes('прямую ссылку') || hint.includes('скач') || hint.includes('download')) node.remove();
        });
    };

    const sanitizeRoot = (root) => root.querySelectorAll('.socialtabs-social-tabs__post').forEach(sanitizePost);

    const init = () => document.querySelectorAll('[data-socialtabs-social-tabs]').forEach((root) => {
        if (root.dataset.initialized) return;
        root.dataset.initialized = '1';
        new SocialTabs(root);
        sanitizeRoot(root);
        const observer = new MutationObserver(() => sanitizeRoot(root));
        observer.observe(root, {childList: true, subtree: true});
    });

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once: true});
    else init();
})();
