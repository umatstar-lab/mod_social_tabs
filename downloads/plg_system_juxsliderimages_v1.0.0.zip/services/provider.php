<?php
defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use JuxSliderImages\Plugin\System\JuxSliderImages\Extension\JuxSliderImages;

return new class implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(PluginInterface::class, function (Container $container) {
            return new JuxSliderImages((array) PluginHelper::getPlugin('system', 'juxsliderimages'));
        });
    }
};
