<?php
namespace JuxSliderImages;
defined('_JEXEC') or die;

final class SliderOutput
{
    public function __construct(private ImageProcessor $images) {}

    /** Keep vendor scripts and slide behaviour; replace only image URLs and the first background. */
    public function process(string $html): array
    {
        $original = ['html'=>$html, 'first'=>null];
        if (!class_exists(\DOMDocument::class)) { return $original; }
        $old = libxml_use_internal_errors(true);
        $doc = new \DOMDocument('1.0', 'UTF-8');
        try {
            $loaded = $doc->loadHTML('<?xml encoding="UTF-8"><div id="jsi-fragment">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET);
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($old);
        }
        $root = $doc->getElementById('jsi-fragment');
        if (!$loaded || !$root) { return $original; }
        $xp = new \DOMXPath($doc);
        $nodes = $xp->query('.//section[starts-with(@id,"jux_image_slider")]//div[contains(concat(" ",normalize-space(@class)," ")," slide-bg-image ")][@data-background]', $root);
        $first = null;
        foreach ($nodes as $node) {
            $url = $node->getAttribute('data-background');
            if ($url === '') { continue; }
            if ($thumbnail = $this->images->thumbnail($url)) {
                $url = $thumbnail['src'];
                $node->setAttribute('data-background', $url);
            }
            if ($first === null) {
                // Skip invalid schemes. The untouched vendor output remains the fallback.
                $scheme = parse_url($url, PHP_URL_SCHEME);
                if ($scheme && !in_array(strtolower($scheme), ['http', 'https'], true)) { continue; }
                $cssUrl = str_replace(["\\", '"', "\r", "\n", "\f"], ["\\\\", '\\"', '', '', ''], $url);
                $style = preg_replace('/(?:^|;)\s*background-image\s*:[^;]*(?:;|$)/i', ';', $node->getAttribute('style'));
                $node->setAttribute('style', rtrim($style, '; ') . ';background-image:url("' . $cssUrl . '")');
                $first = $url;
            }
        }
        if ($first === null) { return $original; }
        $output = '';
        foreach ($root->childNodes as $node) { $output .= $doc->saveHTML($node); }
        return ['html'=>$output, 'first'=>$first];
    }
}
