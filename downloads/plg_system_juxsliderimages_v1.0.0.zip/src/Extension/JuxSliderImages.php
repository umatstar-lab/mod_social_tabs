<?php
namespace JuxSliderImages\Plugin\System\JuxSliderImages\Extension;
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;

// Image processing is invoked by the module layout, without modifying vendor files.
final class JuxSliderImages extends CMSPlugin {}
