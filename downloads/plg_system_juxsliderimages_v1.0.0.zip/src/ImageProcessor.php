<?php
namespace JuxSliderImages;

defined('_JEXEC') or die;

final class ImageProcessor
{
    private string $root;
    private string $imagesRoot;
    private string $cacheDir;
    private string $basePath;
    private string $host;
    private array $memo = [];

    public function __construct(string $root, string $baseUrl, private int $width = 800, private int $quality = 82)
    {
        $this->root = rtrim($root, '/');
        $this->imagesRoot = realpath($this->root . '/images') ?: '';
        $this->cacheDir = $this->root . '/images/juxslider-images';
        $this->basePath = rtrim(parse_url($baseUrl, PHP_URL_PATH) ?: '', '/');
        $this->host = strtolower(parse_url($baseUrl, PHP_URL_HOST) ?: '');
        $this->width = max(320, min(2560, $width));
        $this->quality = max(60, min(95, $quality));
    }

    /** Only local raster images below /images are read. No outbound requests. */
    public function thumbnail(string $url): ?array
    {
        if (array_key_exists($url, $this->memo)) {
            return $this->memo[$url];
        }
        if (count($this->memo) >= 32) {
            return null;
        }
        $this->memo[$url] = null;
        try {
            $result = $this->createThumbnail($url);
        } catch (\Throwable $e) {
            return null;
        }
        return $this->memo[$url] = $result;
    }

    private function createThumbnail(string $url): ?array
    {
        if (!$this->imagesRoot || !function_exists('imagewebp') || !function_exists('imagecreatetruecolor')) {
            return null;
        }
        $parts = parse_url(html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if ($parts === false || isset($parts['user']) || isset($parts['pass'])
            || (isset($parts['scheme']) && !in_array(strtolower($parts['scheme']), ['http', 'https'], true))
            || (isset($parts['host']) && strtolower($parts['host']) !== $this->host)) {
            return null;
        }
        $path = rawurldecode($parts['path'] ?? '');
        if (str_contains($path, "\0") || str_contains($path, '\\')) {
            return null;
        }
        if (str_starts_with($path, '/')) {
            if ($this->basePath && !str_starts_with($path, $this->basePath . '/')) {
                return null;
            }
            $path = substr($path, strlen($this->basePath) + 1);
        }
        if (!str_starts_with($path, 'images/') || str_starts_with($path, 'images/juxslider-images/')) {
            return null;
        }
        $source = realpath($this->root . '/' . $path);
        if (!$source || !str_starts_with($source, $this->imagesRoot . DIRECTORY_SEPARATOR)
            || !is_file($source) || !is_readable($source) || filesize($source) > 20 * 1024 * 1024) {
            return null;
        }
        $info = @getimagesize($source);
        if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)
            || $info[0] < 1 || $info[1] < 1 || $info[0] * $info[1] > 12000000) {
            return null;
        }
        $key = hash('sha256', 'v1|' . $source . '|' . filemtime($source) . '|' . filesize($source)
            . '|' . $this->width . '|' . $this->quality);
        if (!is_dir($this->cacheDir) && !@mkdir($this->cacheDir, 0755, true) && !is_dir($this->cacheDir)) {
            return null;
        }
        $realCache = realpath($this->cacheDir);
        if (!$realCache || !str_starts_with($realCache, $this->imagesRoot . DIRECTORY_SEPARATOR)) {
            return null;
        }
        $file = $realCache . '/' . $key . '.webp';
        if (is_file($file) && ($cached = @getimagesize($file)) && $cached[2] === IMAGETYPE_WEBP) {
            return filesize($file) < filesize($source) ? $this->result($key, $cached) : null;
        }
        $targetWidth = min($this->width, $info[0]);
        $targetHeight = max(1, (int) round($info[1] * $targetWidth / $info[0]));
        $needed = $info[0] * $info[1] * 8 + $targetWidth * $targetHeight * 8 + 16 * 1024 * 1024;
        $limit = ini_get('memory_limit');
        if ($limit && $limit !== '-1') {
            $bytes = (float) $limit;
            $bytes *= match (strtolower(substr($limit, -1))) { 'g'=>1073741824, 'm'=>1048576, 'k'=>1024, default=>1 };
            if (memory_get_usage(true) + $needed > $bytes) {
                return null;
            }
        }
        $orientation = 1;
        if ($info[2] === IMAGETYPE_JPEG) {
            if (function_exists('exif_read_data')) {
                $exif = @exif_read_data($source, 'IFD0', true, false);
                $orientation = (int) ($exif['IFD0']['Orientation'] ?? 1);
            } elseif (str_contains((string) @file_get_contents($source, false, null, 0, 131072), "Exif\0\0")) {
                return null; // Preserve orientation when EXIF support is unavailable.
            }
        }
        $image = match ($info[2]) {
            IMAGETYPE_JPEG => @imagecreatefromjpeg($source),
            IMAGETYPE_PNG => @imagecreatefrompng($source),
            IMAGETYPE_WEBP => @imagecreatefromwebp($source),
        };
        if (!$image) {
            return null;
        }
        $resized = null;
        $temp = null;
        try {
            if (in_array($orientation, [2, 4, 5, 7], true)) {
                imageflip($image, in_array($orientation, [2, 5, 7], true) ? IMG_FLIP_HORIZONTAL : IMG_FLIP_VERTICAL);
            }
            $angle = match ($orientation) { 3=>180, 5=>90, 6=>-90, 7=>-90, 8=>90, default=>0 };
            if ($angle) {
                $rotated = imagerotate($image, $angle, 0);
                if (!$rotated) { return null; }
                imagedestroy($image);
                $image = $rotated;
            }
            $w = imagesx($image);
            $h = imagesy($image);
            $targetWidth = min($this->width, $w);
            $targetHeight = max(1, (int) round($h * $targetWidth / $w));
            $resized = imagecreatetruecolor($targetWidth, $targetHeight);
            imagealphablending($resized, false);
            imagesavealpha($resized, true);
            if (!imagecopyresampled($resized, $image, 0, 0, 0, 0, $targetWidth, $targetHeight, $w, $h)) {
                return null;
            }
            $temp = tempnam($realCache, 'jwi-');
            if (!$temp || !imagewebp($resized, $temp, $this->quality) || !($written = @getimagesize($temp))
                || $written[2] !== IMAGETYPE_WEBP || filesize($temp) >= filesize($source)) {
                return null;
            }
            @chmod($temp, 0644);
            if (!@rename($temp, $file)) { return null; }
            return $this->result($key, $written);
        } finally {
            imagedestroy($image);
            if ($resized) { imagedestroy($resized); }
            if ($temp && is_file($temp)) { @unlink($temp); }
        }
    }

    private function result(string $key, array $info): array
    {
        return ['src'=>$this->basePath . '/images/juxslider-images/' . $key . '.webp', 'width'=>$info[0], 'height'=>$info[1]];
    }

}
