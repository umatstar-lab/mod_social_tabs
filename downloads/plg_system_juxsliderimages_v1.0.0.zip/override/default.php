<?php
// JUXSLIDERIMAGES_MANAGED_LAYOUT_V1
defined('_JEXEC') or die;

$jsiVendor = JPATH_SITE . '/modules/mod_jux_image_slider/tmpl/default.php';
if (!is_file($jsiVendor)) { return; }
if (!\Joomla\CMS\Plugin\PluginHelper::isEnabled('system', 'juxsliderimages')) {
    include $jsiVendor;
    return;
}
$jsiPlugin = \Joomla\CMS\Plugin\PluginHelper::getPlugin('system', 'juxsliderimages');
$jsiOptions = new \Joomla\Registry\Registry($jsiPlugin->params ?? '{}');
ob_start();
try {
    include $jsiVendor;
    $jsiOutput = ob_get_clean();
} catch (\Throwable $e) {
    ob_end_clean();
    throw $e;
}
try {
    require_once JPATH_PLUGINS . '/system/juxsliderimages/src/ImageProcessor.php';
    require_once JPATH_PLUGINS . '/system/juxsliderimages/src/SliderOutput.php';
    $jsiImages = new \JuxSliderImages\ImageProcessor(JPATH_SITE, \Joomla\CMS\Uri\Uri::root(), (int) $jsiOptions->get('width', 1920), (int) $jsiOptions->get('quality', 82));
    $jsiResult = (new \JuxSliderImages\SliderOutput($jsiImages))->process($jsiOutput);
    if ($jsiResult['first'] && $jsiOptions->get('preload', 1)) {
        $jsiDoc = \Joomla\CMS\Factory::getApplication()->getDocument();
        if (method_exists($jsiDoc, 'addHeadLink')) {
            $jsiDoc->addHeadLink($jsiResult['first'], 'preload', 'rel', ['as'=>'image', 'fetchpriority'=>'high']);
        }
    }
    echo $jsiResult['html'];
} catch (\Throwable $e) {
    echo $jsiOutput;
}
