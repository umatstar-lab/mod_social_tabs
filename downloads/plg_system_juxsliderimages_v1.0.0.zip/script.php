<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;

return new class implements InstallerScriptInterface {
    private const MARKER = 'JUXSLIDERIMAGES_MANAGED_LAYOUT_V1';
    private ?string $approvedHash = null;
    private function target(): string { return JPATH_SITE . '/templates/g5_helium/html/mod_jux_image_slider/default.php'; }
    private function ours(string $path): bool
    {
        return is_file($path) && str_contains((string) file_get_contents($path), self::MARKER);
    }
    private function error(string $message): bool
    {
        Factory::getApplication()->enqueueMessage($message, 'error');
        return false;
    }
    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type === 'uninstall') { return true; }
        if (version_compare(JVERSION, '6.0.0', '<')) {
            return $this->error('Это дополнение предназначено для Joomla 6.');
        }
        if (!is_file(JPATH_SITE . '/modules/mod_jux_image_slider/tmpl/default.php')) {
            return $this->error('Сначала установите JUX Image Slider.');
        }
        if (!is_dir(JPATH_SITE . '/templates/g5_helium')) {
            return $this->error('Шаблон g5_helium не найден. Файлы других шаблонов не изменялись.');
        }
        if (!extension_loaded('gd') || !function_exists('imagewebp') || !class_exists(DOMDocument::class)) {
            return $this->error('Требуются PHP GD с WebP и расширение DOM.');
        }
        $path = $this->target();
        if (file_exists($path)) {
            $oldSource = JPATH_PLUGINS . '/system/juxsliderimages/override/default.php';
            if (!$this->ours($path) || !is_file($oldSource) || hash_file('sha256', $path) !== hash_file('sha256', $oldSource)) {
                return $this->error('В g5_helium уже есть пользовательский html/mod_jux_image_slider/default.php. Установка остановлена, чтобы сохранить его. Нужна совместная обработка существующего переопределения.');
            }
            $this->approvedHash = hash_file('sha256', $path);
        }
        return true;
    }
    private function deploy(): bool
    {
        $target = $this->target();
        if (file_exists($target) && (!$this->ours($target) || hash_file('sha256', $target) !== $this->approvedHash)) {
            return $this->error('Существующее переопределение сохранено; установка остановлена.');
        }
        $dir = dirname($target);
        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            return $this->error('Нет прав на создание переопределения в g5_helium.');
        }
        $source = JPATH_PLUGINS . '/system/juxsliderimages/override/default.php';
        if (!@copy($source, $target)) { return $this->error('Не удалось записать переопределение в g5_helium.'); }
        return true;
    }
    public function install(InstallerAdapter $adapter): bool { return $this->deploy(); }
    public function update(InstallerAdapter $adapter): bool { return $this->deploy(); }
    public function uninstall(InstallerAdapter $adapter): bool
    {
        $target = $this->target();
        $source = JPATH_PLUGINS . '/system/juxsliderimages/override/default.php';
        // Remove only an unchanged copy of our layout. Leave any user-edited file.
        if (is_file($target) && is_file($source) && hash_file('sha256', $target) === hash_file('sha256', $source)) {
            @unlink($target);
        }
        // Edited wrappers remain harmless after removal: they check plugin enablement first.
        return true;
    }
    public function postflight(string $type, InstallerAdapter $adapter): bool { return true; }
};
