<?php
defined('_JEXEC') or die;
use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;

return new class implements InstallerScriptInterface {
    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type === 'uninstall') { return true; }
        if (version_compare(JVERSION, '6.0.0', '<') || !class_exists(DOMDocument::class)) {
            Factory::getApplication()->enqueueMessage('Для этого дополнения нужны Joomla 6 и расширение PHP DOM.', 'error');
            return false;
        }
        return true;
    }
    public function install(InstallerAdapter $adapter): bool { return true; }
    public function update(InstallerAdapter $adapter): bool { return true; }
    public function uninstall(InstallerAdapter $adapter): bool { return true; }
    public function postflight(string $type, InstallerAdapter $adapter): bool { return true; }
};
