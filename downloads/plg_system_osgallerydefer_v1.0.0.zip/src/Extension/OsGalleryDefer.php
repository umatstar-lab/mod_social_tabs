<?php
namespace OsGalleryDefer\Plugin\System\OsGalleryDefer\Extension;
defined('_JEXEC') or die;

use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Event\Application\BeforeCompileHeadEvent;
use Joomla\CMS\Event\Application\AfterRenderEvent;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\Priority;
use Joomla\Event\SubscriberInterface;

final class OsGalleryDefer extends CMSPlugin implements SubscriberInterface
{
    public function __construct(array $config, private CMSApplicationInterface $app)
    {
        parent::__construct($config);
    }
    public static function getSubscribedEvents(): array
    {
        return ['onBeforeCompileHead'=>'onBeforeCompileHead', 'onAfterRender'=>['onAfterRender', Priority::LOW]];
    }
    private function frontend(): bool
    {
        return $this->app->isClient('site') && $this->app->getDocument()->getType() === 'html'
            && !($this->app->getInput()->getCmd('view') === 'form' && $this->app->getInput()->getCmd('layout') === 'edit');
    }
    public function onBeforeCompileHead(BeforeCompileHeadEvent $event): void
    {
        if (!$this->frontend()) { return; }
        $this->app->getDocument()->getWebAssetManager()->registerAndUseScript('plg_system.osgallerydefer', 'plg_system_osgallerydefer/defer.js', ['version'=>'1.0.0'], ['defer'=>true]);
    }
    public function onAfterRender(AfterRenderEvent $event): void
    {
        if (!$this->frontend()) { return; }
        require_once dirname(__DIR__) . '/HiddenImages.php';
        $body = $this->app->getBody();
        try { $this->app->setBody(\OsGalleryDefer\HiddenImages::process($body)); }
        catch (\Throwable $e) { /* Keep the original page on processing failure. */ }
    }
}
