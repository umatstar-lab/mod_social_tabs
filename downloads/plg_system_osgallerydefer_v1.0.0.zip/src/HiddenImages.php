<?php
namespace OsGalleryDefer;
defined('_JEXEC') or die;

final class HiddenImages
{
    public const PIXEL = 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=';

    /** Preserve the page byte-for-byte except img/source tags inside OS Gallery's hidden HTML popups. */
    public static function process(string $html): string
    {
        if (!str_contains($html, 'data-html-wrap') || !class_exists(\DOMDocument::class)) { return $html; }
        $pattern = '~<!--[\s\S]*?-->|<(script|style|textarea|template)\b(?:"[^"]*"|\x27[^\x27]*\x27|[^\x27">])*?>[\s\S]*?</\1\s*>|</?[a-zA-Z][a-zA-Z0-9:-]*\b(?:"[^"]*"|\x27[^\x27]*\x27|[^\x27">])*>~i';
        if (!preg_match_all($pattern, $html, $matches, PREG_OFFSET_CAPTURE)) { return $html; }
        $stack = [];
        $hidden = false;
        $offset = 0;
        $result = '';
        foreach ($matches[0] as [$tag, $position]) {
            if (preg_match('~^<div\b~i', $tag)) {
                $stack[] = $hidden;
                if (preg_match('~\bclass\s*=\s*(["\x27])([^"\x27]*)\1~i', $tag, $classes)
                    && preg_match('/(?:^|\s)data-html-wrap(?:\s|$)/', $classes[2])
                    && preg_match('~\bid\s*=\s*(["\x27])data-html-[0-9]+\1~i', $tag)) {
                    $hidden = true;
                }
            } elseif (preg_match('~^</div\b~i', $tag)) {
                $hidden = $stack ? array_pop($stack) : false;
            } elseif ($hidden && preg_match('~^<(img|source)\b~i', $tag)) {
                $replacement = self::deferTag($tag);
                if ($replacement !== $tag) {
                    $result .= substr($html, $offset, $position - $offset) . $replacement;
                    $offset = $position + strlen($tag);
                }
            }
        }
        return $offset ? $result . substr($html, $offset) : $html;
    }

    private static function deferTag(string $tag): string
    {
        $old = libxml_use_internal_errors(true);
        $doc = new \DOMDocument('1.0', 'UTF-8');
        try {
            $doc->loadHTML('<?xml encoding="UTF-8"><div>' . $tag . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET);
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($old);
        }
        $name = preg_match('~^<source\b~i', $tag) ? 'source' : 'img';
        $node = $doc->getElementsByTagName($name)->item(0);
        if (!$node) { return $tag; }
        // News Wall's existing optimizer may already own this image; leave it untouched.
        if ($node->hasAttribute('data-jwi-src') || $node->hasAttribute('data-jwi-srcset')
            || $node->hasAttribute('data-osgd-src') || $node->hasAttribute('data-osgd-srcset')) { return $tag; }
        $changed = false;
        foreach (['src', 'srcset'] as $attr) {
            if ($node->hasAttribute($attr) && $node->getAttribute($attr) !== '') {
                $value = $node->getAttribute($attr);
                if ($attr === 'src' && str_starts_with(strtolower($value), 'data:')) { continue; }
                $node->setAttribute('data-osgd-' . $attr, $value);
                $node->removeAttribute($attr);
                $changed = true;
            }
        }
        if (!$changed) { return $tag; }
        if ($name === 'img') { $node->setAttribute('src', self::PIXEL); }
        return $doc->saveHTML($node);
    }
}
