(function () {
    'use strict';
    if (window.osGalleryDeferInstalled) return;
    window.osGalleryDeferInstalled = true;

    function hydrate(scope) {
        if (!scope || !scope.querySelectorAll) return;
        scope.querySelectorAll('source[data-osgd-srcset]').forEach(function (node) {
            node.setAttribute('srcset', node.getAttribute('data-osgd-srcset'));
            node.removeAttribute('data-osgd-srcset');
        });
        scope.querySelectorAll('img[data-osgd-src], img[data-osgd-srcset]').forEach(function (node) {
            ['srcset', 'src'].forEach(function (attr) {
                if (!node.hasAttribute('data-osgd-' + attr)) return;
                node.setAttribute(attr, node.getAttribute('data-osgd-' + attr));
                node.removeAttribute('data-osgd-' + attr);
            });
        });
    }

    document.addEventListener('click', function (event) {
        var link = event.target.closest && event.target.closest('a[data-options]');
        if (!link || !link.id || !/^os_image_id-\d+$/.test(link.id)) return;
        var options;
        try { options = JSON.parse(link.getAttribute('data-options')); } catch (e) { return; }
        if (typeof options.src === 'string' && /^#data-html-\d+$/.test(options.src)) {
            hydrate(document.getElementById(options.src.slice(1)));
        }
    }, true);

    // OS Gallery uses a renamed Fancybox; its lifecycle event namespace remains .fb.
    if (window.jQuerOs) {
        window.jQuerOs(document).on('beforeLoad.fb.osgd', function (event, instance, slide) {
            if (slide && typeof slide.src === 'string' && /^#data-html-\d+$/.test(slide.src)) {
                hydrate(document.getElementById(slide.src.slice(1)));
            }
        });
        // Raw HTML returned by gallery AJAX must be processed before jQuery inserts it.
        window.jQuerOs.ajaxPrefilter(function (options) {
            var data = options.data;
            var destination = options.url || '';
            var gallery = /(?:[?&])option=com_osgallery(?:&|$)/.test(destination)
                || (typeof data === 'string' && /(?:^|&)option=com_osgallery(?:&|$)/.test(data))
                || (data && typeof data === 'object' && data.option === 'com_osgallery');
            if (!gallery || /json|script|jsonp/i.test(options.dataType || '')) return;
            var previous = options.dataFilter;
            options.dataFilter = function (response, type) {
                if (previous) response = previous.call(this, response, type);
                if (typeof response !== 'string' || response.indexOf('data-html-wrap') === -1) return response;
                var template = document.createElement('template');
                template.innerHTML = response; // Template contents are inert: no image requests.
                template.content.querySelectorAll('.data-html-wrap[id^="data-html-"] img, .data-html-wrap[id^="data-html-"] source').forEach(function (node) {
                    if (node.hasAttribute('data-jwi-src') || node.hasAttribute('data-jwi-srcset') || node.hasAttribute('data-osgd-src') || node.hasAttribute('data-osgd-srcset')) return;
                    var changed = false;
                    ['src', 'srcset'].forEach(function (attr) {
                        var value = node.getAttribute(attr);
                        if (!value || (attr === 'src' && /^data:/i.test(value))) return;
                        node.setAttribute('data-osgd-' + attr, value);
                        node.removeAttribute(attr);
                        changed = true;
                    });
                    if (changed && node.tagName === 'IMG') node.setAttribute('src', 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=');
                });
                return template.innerHTML;
            };
        });
    }

    new MutationObserver(function (records) {
        records.forEach(function (record) {
            record.addedNodes.forEach(function (node) {
                if (node.nodeType !== 1) return;
                if (node.matches('.os_fancybox-container, .os_fancybox-content') || node.closest('.os_fancybox-container')) hydrate(node);
                node.querySelectorAll('.os_fancybox-container, .os_fancybox-content').forEach(hydrate);
            });
        });
    }).observe(document.documentElement, {childList: true, subtree: true});
})();
