<?php
defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use OsGalleryDefer\Plugin\System\OsGalleryDefer\Extension\OsGalleryDefer;

return new class implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(PluginInterface::class, function (Container $container) {
            return new OsGalleryDefer((array) PluginHelper::getPlugin('system', 'osgallerydefer'), \Joomla\CMS\Factory::getApplication());
        });
    }
};
